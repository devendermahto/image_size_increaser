# Image Size Increaser

A Python library to increase the size of an image file.

## Installation
python setup.py sdist
```bash
pip install .